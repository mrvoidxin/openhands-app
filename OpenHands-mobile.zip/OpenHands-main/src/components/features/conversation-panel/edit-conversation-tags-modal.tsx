import React from "react";
import { useTranslation } from "react-i18next";
import { X } from "lucide-react";
import {
  BaseModalDescription,
  BaseModalTitle,
} from "#/components/shared/modals/confirmation-modals/base-modal";
import { ModalBackdrop } from "#/components/shared/modals/modal-backdrop";
import { ModalBody } from "#/components/shared/modals/modal-body";
import { BrandButton } from "../settings/brand-button";
import { I18nKey } from "#/i18n/declaration";
import {
  getDisplayConversationTags,
  RESERVED_CONVERSATION_TAG_KEYS,
} from "#/api/agent-server-adapter";

/** Backend rule for tag keys (see `ConversationInfo.tags` in the SDK). */
export const CONVERSATION_TAG_KEY_PATTERN = /^[a-z0-9]+$/;
/** Backend cap on tag values (see `ConversationInfo.tags` in the SDK). */
export const CONVERSATION_TAG_VALUE_MAX_LENGTH = 256;

interface TagRow {
  key: string;
  value: string;
}

/**
 * Merges the user's edited display tags with every entry the display helper
 * drops from the current map (reserved/internal keys, whitespace-only or
 * non-string values), so the replace-all PATCH never silently discards
 * internal tags. Bare tags (empty-string values) are user-manageable and
 * come through `editedUserTags` like any valued tag.
 */
export function mergeConversationTagEdits(
  currentTags: Record<string, string> | null | undefined,
  editedUserTags: readonly (readonly [string, string])[],
): Record<string, string> {
  const merged: Record<string, string> = {};
  for (const [key, value] of Object.entries(currentTags ?? {})) {
    // Preserve what the editor does not surface: reserved keys, non-string
    // values, and whitespace-only values (raw-write junk the display drops).
    // Empty-string values are bare tags — the editor manages them, so they
    // must NOT be preserved here or a removed bare tag would resurrect.
    if (
      RESERVED_CONVERSATION_TAG_KEYS.has(key.trim().toLowerCase()) ||
      typeof value !== "string" ||
      (value !== "" && value.trim().length === 0)
    ) {
      merged[key] = value;
    }
  }
  for (const [key, value] of editedUserTags) {
    merged[key] = value;
  }
  return merged;
}

interface EditConversationTagsModalProps {
  /** The conversation's complete server-side tag map (including internals). */
  tags: Record<string, string> | null | undefined;
  /** Called with the merged complete map (user edits + preserved internals). */
  onConfirm: (mergedTags: Record<string, string>) => void;
  onCancel: () => void;
}

export function EditConversationTagsModal({
  tags,
  onConfirm,
  onCancel,
}: EditConversationTagsModalProps) {
  const { t } = useTranslation("openhands");
  const [rows, setRows] = React.useState<TagRow[]>(() =>
    getDisplayConversationTags(tags).map(([key, value]) => ({ key, value })),
  );
  const [newKey, setNewKey] = React.useState("");
  const [newValue, setNewValue] = React.useState("");
  const [errorKey, setErrorKey] = React.useState<I18nKey | null>(null);
  const keyInputRef = React.useRef<HTMLInputElement>(null);

  /**
   * Validates whatever is sitting in the key/value inputs against the backend's
   * tag rules and the rows already staged. Shared by Add and Save so both
   * doors apply the same checks.
   */
  const buildPendingRow = (): { row: TagRow } | { errorKey: I18nKey } => {
    const key = newKey.trim();
    const value = newValue.trim();
    if (!CONVERSATION_TAG_KEY_PATTERN.test(key)) {
      return { errorKey: I18nKey.CONVERSATION$TAG_KEY_INVALID };
    }
    if (RESERVED_CONVERSATION_TAG_KEYS.has(key)) {
      return { errorKey: I18nKey.CONVERSATION$TAG_KEY_RESERVED };
    }
    if (rows.some((row) => row.key === key)) {
      return { errorKey: I18nKey.CONVERSATION$TAG_KEY_DUPLICATE };
    }
    // The value is optional: an empty value is a bare tag — stored as "" (the
    // backend validator allows it) and rendered as just the key.
    if (value.length > CONVERSATION_TAG_VALUE_MAX_LENGTH) {
      return { errorKey: I18nKey.CONVERSATION$TAG_VALUE_INVALID };
    }
    return { row: { key, value } };
  };

  const handleAdd = () => {
    const result = buildPendingRow();
    if ("errorKey" in result) {
      setErrorKey(result.errorKey);
      return;
    }
    setRows((prev) => [...prev, result.row]);
    setNewKey("");
    setNewValue("");
    setErrorKey(null);
    // Ready for the next tag: focus returns to the key box, not the value box.
    keyInputRef.current?.focus();
  };

  const handleInputKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === "Enter") {
      event.preventDefault();
      handleAdd();
    }
  };

  const handleRemove = (key: string) => {
    setRows((prev) => prev.filter((row) => row.key !== key));
  };

  const handleConfirm = () => {
    // Add is an affordance for entering several tags, not a toll on entering
    // one: a tag typed into the inputs and never Added is still a tag the user
    // asked for, so Save commits it. If it doesn't validate, surface the error
    // and keep the modal open — never drop the typing on the floor.
    const hasPendingInput = newKey.trim() !== "" || newValue.trim() !== "";
    let committedRows = rows;
    if (hasPendingInput) {
      const result = buildPendingRow();
      if ("errorKey" in result) {
        setErrorKey(result.errorKey);
        return;
      }
      committedRows = [...rows, result.row];
    }

    onConfirm(
      mergeConversationTagEdits(
        tags,
        committedRows.map((row) => [row.key, row.value] as const),
      ),
    );
  };

  return (
    <ModalBackdrop onClose={onCancel}>
      <ModalBody
        className="items-start border border-border"
        testID="edit-conversation-tags-modal"
      >
        <div className="flex flex-col gap-2">
          <BaseModalTitle title={t(I18nKey.CONVERSATION$EDIT_TAGS)} />
          <BaseModalDescription>
            {t(I18nKey.CONVERSATION$EDIT_TAGS_DESCRIPTION)}
          </BaseModalDescription>
        </div>

        <div
          className="flex w-full flex-col gap-2"
          onClick={(event) => event.stopPropagation()}
        >
          {rows.length > 0 ? (
            <ul
              className="flex w-full flex-col gap-1"
              data-testid="edit-tags-rows"
            >
              {rows.map((row) => (
                <li
                  key={row.key}
                  className="flex items-center gap-2 rounded-md border border-border px-2 py-1"
                  data-testid={`edit-tag-row-${row.key}`}
                >
                  <span className="min-w-0 flex-1 truncate text-xs text-contrast">
                    {row.value ? `${row.key}=${row.value}` : row.key}
                  </span>
                  <button
                    type="button"
                    aria-label={t(I18nKey.CONVERSATION$REMOVE_TAG)}
                    data-testid={`remove-tag-${row.key}`}
                    onClick={() => handleRemove(row.key)}
                    className="shrink-0 text-muted hover:text-contrast"
                  >
                    <X className="h-3.5 w-3.5" aria-hidden />
                  </button>
                </li>
              ))}
            </ul>
          ) : null}

          <div className="flex w-full items-center gap-2">
            <input
              type="text"
              value={newKey}
              placeholder={t(I18nKey.CONVERSATION$TAG_KEY_PLACEHOLDER)}
              aria-label={t(I18nKey.CONVERSATION$TAG_KEY_PLACEHOLDER)}
              data-testid="new-tag-key-input"
              ref={keyInputRef}
              onChange={(event) => setNewKey(event.target.value)}
              onKeyDown={handleInputKeyDown}
              className="w-28 shrink-0 rounded-md border border-border bg-base-secondary px-2 py-1 text-xs text-contrast placeholder:text-muted"
            />
            <input
              type="text"
              value={newValue}
              placeholder={t(I18nKey.CONVERSATION$TAG_VALUE_PLACEHOLDER)}
              aria-label={t(I18nKey.CONVERSATION$TAG_VALUE_PLACEHOLDER)}
              data-testid="new-tag-value-input"
              onChange={(event) => setNewValue(event.target.value)}
              onKeyDown={handleInputKeyDown}
              className="min-w-0 flex-1 rounded-md border border-border bg-base-secondary px-2 py-1 text-xs text-contrast placeholder:text-muted"
            />
            <BrandButton
              type="button"
              variant="secondary"
              onClick={handleAdd}
              testId="add-tag-button"
            >
              {t(I18nKey.BUTTON$ADD)}
            </BrandButton>
          </div>

          {errorKey ? (
            <p
              role="alert"
              data-testid="edit-tags-error"
              className="text-xs text-feedback-error"
            >
              {t(errorKey)}
            </p>
          ) : null}
        </div>

        <div
          className="flex justify-end gap-2 w-full"
          onClick={(event) => event.stopPropagation()}
        >
          <BrandButton
            type="button"
            variant="secondary"
            onClick={onCancel}
            testId="cancel-button"
          >
            {t(I18nKey.BUTTON$CANCEL)}
          </BrandButton>
          <BrandButton
            type="button"
            variant="primary"
            onClick={handleConfirm}
            testId="confirm-button"
          >
            {t(I18nKey.BUTTON$SAVE)}
          </BrandButton>
        </div>
      </ModalBody>
    </ModalBackdrop>
  );
}
