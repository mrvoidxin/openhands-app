import { useTranslation } from "react-i18next";

import { I18nKey } from "#/i18n/declaration";
import { useColorTheme } from "#/hooks/use-color-theme";
import { useWorkspaceFileContent } from "#/hooks/query/use-workspace-file-content";
import {
  useWorkspaceMutationCounter,
  withWorkspaceCacheBuster,
} from "#/stores/use-workspace-mutation-counter";
import { MarkdownRenderer } from "#/components/features/markdown/markdown-renderer";
import { isMarkdownFilePath } from "#/utils/is-markdown-file-path";
import { COLOR_THEMES } from "#/themes/color-themes";
import { cn } from "#/utils/utils";
import { HighlightedSourceView } from "./highlighted-source-view";
import type { ViewMode } from "./view-mode";

interface FileContentViewerProps {
  path: string;
  viewMode: ViewMode;
}

const HTML_LIKE_EXTS = new Set(["html", "htm", "svg"]);

// Office/document formats we can't preview inline. The label doubles as the
// allow-list (a present entry => Office doc) and feeds a clear, format-named
// "no preview" message instead of the generic binary fallback.
const OFFICE_DOCUMENT_LABELS: Record<string, string> = {
  pptx: "PowerPoint",
  ppt: "PowerPoint",
  docx: "Word",
  doc: "Word",
  xlsx: "Excel",
  xls: "Excel",
};

function getExtension(path: string): string {
  const idx = path.lastIndexOf(".");
  return idx === -1 ? "" : path.slice(idx + 1).toLowerCase();
}

/**
 * Fallback shown when a file's bytes aren't previewable. Office documents
 * (.pptx / .docx / .xlsx …) get a clear, format-named message; every other
 * binary keeps the generic "binary file" string so the pane is never blank.
 */
function UnpreviewableFallback({ path }: { path: string }) {
  const { t } = useTranslation("openhands");
  const documentLabel = OFFICE_DOCUMENT_LABELS[getExtension(path)];
  return (
    <div
      className="flex h-full w-full items-center justify-center text-sm text-muted"
      data-testid={
        documentLabel
          ? "file-content-viewer-unsupported-document"
          : "file-content-viewer-binary-fallback"
      }
    >
      {documentLabel
        ? t(I18nKey.FILES$UNSUPPORTED_DOCUMENT, { type: documentLabel })
        : t(I18nKey.FILES$BINARY_FALLBACK)}
    </div>
  );
}

/**
 * Renders the contents of a single workspace file. In `rich` mode we point
 * an iframe / <img> straight at the agent server's static workspace
 * fileserver for HTML / SVG / images / PDFs, so relative asset references
 * load naturally. In `plain` mode we always show the raw bytes as text (or
 * a fallback message for binaries).
 */
export function FileContentViewer({ path, viewMode }: FileContentViewerProps) {
  const { t } = useTranslation("openhands");
  const colorTheme = useColorTheme();
  const isLightTheme = COLOR_THEMES[colorTheme].appearance === "light";
  const query = useWorkspaceFileContent(path);
  // Subscribe to the workspace mutation counter so the iframe / <img> src
  // changes after every agent file-editor edit and every Files tab Refresh,
  // forcing a fresh fetch of the displayed file even when the *path* hasn't
  // moved. Assets it references (e.g. a `style.css` used by `index.html`)
  // keep their own URLs, so they are not cache-busted by this.
  const mutationCounter = useWorkspaceMutationCounter((state) => state.count);

  if (query.isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center text-sm text-muted">
        {t(I18nKey.FILES$LOADING_FILES)}
      </div>
    );
  }

  if (query.isError || !query.data) {
    // Show a load-error message rather than the binary-fallback string —
    // these are completely different failure modes (couldn't even fetch
    // the file vs. fetched fine but the bytes aren't previewable) and
    // mixing them up hides real backend failures behind a misleading
    // "Binary file" label. Prefer the underlying error's own message when
    // we have one; fall back to the generic translated string otherwise.
    return (
      <div
        className="flex h-full w-full items-center justify-center text-sm text-muted"
        data-testid="file-content-viewer-error"
      >
        {(query.error as Error | undefined)?.message ??
          t(I18nKey.FILES$LOAD_ERROR)}
      </div>
    );
  }

  const { kind, text, staticUrl, mimeType } = query.data;
  const bustedStaticUrl = withWorkspaceCacheBuster(staticUrl, mutationCounter);

  // ----- Plain mode: raw source bytes, syntax-highlighted when we can
  // recognize the grammar (falls through to a `<pre>` otherwise). This
  // includes "plain" view of markdown / HTML, where the point is to see
  // the markup behind the rich preview.
  if (viewMode === "plain") {
    if (kind === "text" && text !== null) {
      return (
        <HighlightedSourceView
          path={path}
          text={text}
          mimeType={mimeType ?? undefined}
        />
      );
    }
    return <UnpreviewableFallback path={path} />;
  }

  // ----- Rich mode: render HTML, markdown, images, PDFs from staticUrl. ----
  if (kind === "image") {
    return (
      <div
        className="flex h-full w-full items-center justify-center bg-surface p-4"
        data-testid="file-content-viewer-image"
      >
        <img
          src={bustedStaticUrl}
          alt={path}
          className="max-h-full max-w-full object-contain"
        />
      </div>
    );
  }

  if (kind === "pdf") {
    // Deliberately NOT sandboxed: Chromium refuses to instantiate its
    // built-in PDF viewer inside any sandboxed frame (the `sandbox`
    // attribute disables plugins unconditionally — no token re-enables
    // them), rendering "This page has been blocked by Chrome" instead of
    // the document. Unsandboxed is safe here: the fileserver declares
    // `Content-Type: application/pdf`, which browsers never sniff into
    // HTML, so the frame can only host the PDF viewer — and PDF-embedded
    // JS (AcroForm, OpenAction…) runs in the viewer's own sandboxed
    // engine with no access to this page's DOM.
    return (
      <iframe
        title={path}
        src={bustedStaticUrl}
        data-testid="file-content-viewer-iframe"
        className="h-full w-full bg-white"
      />
    );
  }

  if (kind === "binary") {
    return <UnpreviewableFallback path={path} />;
  }

  // Text-like content.
  if (mimeType === "text/html" || HTML_LIKE_EXTS.has(getExtension(path))) {
    // Sandbox the preview iframe: `allow-same-origin` keeps the frame on
    // the workspace fileserver's origin so relative `<link href="…">`,
    // `<img src="…">`, etc. continue to resolve, while the absence of
    // `allow-scripts` means any `<script>` (or `onerror=…`, inline event
    // handler, …) inside the previewed file is inert. This is exactly
    // the safe-preview posture we want — users can look at their HTML
    // without it executing in the canvas's context.
    return (
      <iframe
        title={path}
        src={bustedStaticUrl}
        sandbox="allow-same-origin"
        data-testid="file-content-viewer-iframe"
        className="h-full w-full bg-white"
      />
    );
  }

  if (kind === "text" && isMarkdownFilePath(path)) {
    // Match the right-pane chrome color so the rich-rendered markdown
    // blends with the surrounding files tab instead of painting a stark
    // white card. `--oh-scroll-fade-from` keeps wide-table edge fades on
    // the same surface (otherwise they default to `--oh-color-base`).
    return (
      <div
        data-testid="file-content-viewer-markdown"
        className="h-full w-full overflow-auto bg-surface text-foreground custom-scrollbar-always [--oh-scroll-fade-from:var(--oh-surface)]"
      >
        <div
          className={cn(
            "prose prose-sm max-w-none p-6",
            "[--tw-prose-body:var(--oh-foreground)] [--tw-prose-bold:var(--oh-foreground)] [--tw-prose-headings:var(--oh-foreground)] [--tw-prose-lead:var(--oh-text-secondary)] [--tw-prose-counters:var(--oh-text-secondary)] [--tw-prose-quotes:var(--oh-foreground)] [--tw-prose-quote-borders:var(--oh-border-subtle)] [--tw-prose-bullets:var(--oh-muted)] [--tw-prose-hr:var(--oh-border-subtle)] [--tw-prose-captions:var(--oh-muted)] [--tw-prose-kbd:var(--oh-foreground)]",
            !isLightTheme && "prose-invert",
          )}
        >
          <MarkdownRenderer
            content={text ?? ""}
            includeStandard
            includeHeadings
          />
        </div>
      </div>
    );
  }

  // Rich mode for actual source code (.ts, .py, .yaml, .css, …): there
  // is no other "rich" rendering to fall back to, so highlighted source
  // IS the rich view. Identical to the plain-mode treatment — keeping
  // both branches reuse `HighlightedSourceView` means the toggle has the
  // same visual identity for source files in both modes (which is the
  // honest answer: source IS rendered code).
  if (kind === "text" && text !== null) {
    return (
      <HighlightedSourceView
        path={path}
        text={text}
        mimeType={mimeType ?? undefined}
      />
    );
  }

  // Truly unknown / empty payload — show a fallback so the pane is never
  // blank.
  return <UnpreviewableFallback path={path} />;
}
