import { CompactSectionNavigation } from "#/components/shared/compact-section-navigation";
import { useNavigation } from "#/context/navigation-context";
import { useTranslation } from "react-i18next";
import { cn } from "#/utils/utils";
import { Typography } from "#/ui/typography";
import { I18nKey } from "#/i18n/declaration";
import { SettingsNavRenderedItem } from "#/hooks/use-settings-nav-items";
import { SidebarNavLink } from "#/components/features/sidebar/sidebar-nav-link";
import { AgentCanvasUpdateCard } from "#/components/features/settings/agent-canvas-update-card";
import { BackendSyncedSettingsBadge } from "#/components/features/settings/backend-synced-settings-badge";
import { CloudSettingsLink } from "#/components/features/settings/cloud-settings-link";
import { IntegrationsSettingsLink } from "#/components/features/settings/integrations-settings-link";

interface SettingsDesktopSidebarProps {
  navigationItems: SettingsNavRenderedItem[];
}

/**
 * Desktop sidebar — sibling of the scrolling main column (same pattern as
 * {@link ExtensionsNavigation}). Mobile drawer stays `position: fixed` outside
 * this row in the layout.
 */
export function SettingsDesktopSidebar({
  navigationItems,
}: SettingsDesktopSidebarProps) {
  const { t } = useTranslation("openhands");

  return (
    <aside
      data-testid="settings-navbar-desktop"
      className={cn(
        "hidden lg:flex lg:w-65 lg:shrink-0 lg:flex-col lg:gap-2",
        "lg:sticky lg:top-8 lg:self-start lg:pl-8",
      )}
    >
      <Typography.Text className="px-2 text-sm font-normal text-contrast">
        {t(I18nKey.SETTINGS$TITLE)}
      </Typography.Text>
      <SettingsNavigationLinks navigationItems={navigationItems} />
      <div className="flex flex-col gap-2 px-2 pt-3">
        <AgentCanvasUpdateCard />
      </div>
      <div className="px-2 pt-3">
        <BackendSyncedSettingsBadge />
      </div>
    </aside>
  );
}

function SettingsNavigationLinks({
  navigationItems,
}: SettingsDesktopSidebarProps) {
  const { t } = useTranslation("openhands");
  const desktopNavItems = navigationItems.filter(
    (item): item is Extract<SettingsNavRenderedItem, { type: "item" }> =>
      item.type === "item",
  );
  return (
    <div className="flex flex-col gap-0.5 pt-0.5">
      {desktopNavItems.map((renderedItem) => (
        <SidebarNavLink
          key={renderedItem.item.to}
          to={renderedItem.item.to}
          label={t(renderedItem.item.text as I18nKey)}
          testId={`sidebar-settings-${renderedItem.item.to}`}
          icon={renderedItem.item.icon}
        />
      ))}
      <IntegrationsSettingsLink />
      <CloudSettingsLink />
    </div>
  );
}

export function SettingsCompactNavigation({
  navigationItems,
}: SettingsDesktopSidebarProps) {
  const { t } = useTranslation("openhands");
  const { currentPath } = useNavigation();
  const currentItem = navigationItems.find(
    (item) =>
      item.type === "item" &&
      (item.item.to === currentPath ||
        currentPath.startsWith(`${item.item.to}/`)),
  );

  return (
    <CompactSectionNavigation
      label={t(I18nKey.SETTINGS$TITLE)}
      currentLabel={
        currentItem?.type === "item"
          ? t(currentItem.item.text as I18nKey)
          : undefined
      }
      testId="settings-compact-navigation"
    >
      <SettingsNavigationLinks navigationItems={navigationItems} />
    </CompactSectionNavigation>
  );
}
