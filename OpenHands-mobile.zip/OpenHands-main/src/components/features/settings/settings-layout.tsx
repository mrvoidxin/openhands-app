import {
  SettingsDesktopSidebar,
  SettingsCompactNavigation,
} from "./settings-desktop-sidebar";
import { SettingsNavRenderedItem } from "#/hooks/use-settings-nav-items";
import { settingsLayoutMainScrollClassName } from "#/utils/settings-like-page-layout-classes";

interface SettingsLayoutProps {
  children: React.ReactNode;
  navigationItems: SettingsNavRenderedItem[];
}

/**
 * Mirrors the extensions layout (Skills / MCP): aside and main are siblings,
 * and only the main column scrolls so the left nav stays pinned like
 * ExtensionsNavigation.
 */
export function SettingsLayout({
  children,
  navigationItems,
}: SettingsLayoutProps) {
  return (
    <div className="flex h-full flex-col lg:pt-8">
      <div className="flex min-h-0 flex-1 gap-10 lg:items-start">
        <SettingsDesktopSidebar navigationItems={navigationItems} />
        <main className={settingsLayoutMainScrollClassName}>
          <div className="mx-auto flex w-full min-w-0 max-w-200 flex-col gap-6">
            <SettingsCompactNavigation navigationItems={navigationItems} />
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
